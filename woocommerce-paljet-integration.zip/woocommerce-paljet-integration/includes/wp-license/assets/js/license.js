(function ($) {

	const ERPWooSyncLicense = {
		/**
		 * Start the engine.
		 *
		 * @since 2.0.0
		 */
		init: function () {

			// Document ready
			$(document).ready(ERPWooSyncLicense.ready);

			// Page load
			$(window).on('load', ERPWooSyncLicense.load);
		},

		/**
		 * Page load.
		 *
		 * @since 2.0.0
		 */
		load: function () {

		},

		/**
		 * Document ready.
		 *
		 * @since 1.0.0
		 */
		ready: function () {

			// Bind all actions.
			ERPWooSyncLicense.bindUIActions();
		},

		/**
		 * Element bindings.
		 *
		 * @since 1.0.0
		 */
		bindUIActions: function () {

			// OpenPopup when the user click "Manage License"
			$('.erpwoosync_license').on( 'click', function(e) {
				e.preventDefault();
				
				const slug = $(this).data('slug');
				ERPWooSyncLicense.openPopup(slug);
			});

			// Unassign the license from erpwoosync
			$(document).on('click', '#erpwoosync_button_unassign', function(e) {
				e.preventDefault();
				const slug = $(this).data('slug');

				ERPWooSyncLicense.unassignLicense(slug);
			});

			// ClosePopup when the user click "close popup"
			$('#erpwoosync_box_close').on( 'click', function(e) {
				e.preventDefault();

				const slug = $('#erpwoosync_box_license').attr('class');
				ERPWooSyncLicense.closePopup(slug);
			});

			// ClosePopup when the user push ESC
			$(document).keyup(function(e) {
				if (e.keyCode == 27) {
					const slug = $('#erpwoosync_box_license').attr('class');
					ERPWooSyncLicense.closePopup(slug);
				}
			});
		},
		/**
		 * Open Popup Event
		 * 
		 * @since 1.0.0
		 */
		openPopup: function(slug = '') {
			const loading = '<div style="text-align:center;">' + letsgo.loading_html + '</div>';

			// Remove all the messages
			$('#erpwoosync_box_message').removeClass('error').removeClass('success').removeClass('warning');
			
			// Put the class
			$('#erpwoosync_box_license').addClass(slug);

			// Open the popup
			$('#erpwoosync_box_license').slideDown('fast');

			// Put loading icon in message section
			$('#erpwoosync_box_message').html(loading);
			
			// Empty button content
			$('#erpwoosync_box_button').empty();


			// We prepare the information to Ajax event
			const data = {
				action: slug + '_get_status',
				wpnonce: letsgo.wpnonce
			};

			const onSuccess = function (response) {
				
				$('#erpwoosync_box_message').addClass(response.data.class);
				$('#erpwoosync_box_message').html(response.data.message);

				if( response.success && response.data.isactive ) {
					const iunassined = '<button id="erpwoosync_button_unassign" data-slug="' + slug + '">' + letsgo.unassign_text + '</button>';
					$('#erpwoosync_box_button').html(iunassined);
				}
			};

			const onError = function(jqxhr, textStatus, error) {
				console.log('License Ajax error: ' + textStatus + ' - ' + error);
			};


			if( letsgo && letsgo.ajax_url ) {
				ERPWooSyncLicense.sendAjax(data, onSuccess, onError);
			}
		},
		/**
		 * Close Popup Event
		 * 
		 * @since 1.0.0
		 */
		closePopup : function(slug = '') {
			$('#erpwoosync_box_license').removeClass(slug);
			$('#erpwoosync_box_license').slideUp('fast');
		},

		/**
		 * Unassign License Event
		 * 
		 * @since 1.0.0
		 */
		unassignLicense : function(slug = '') {
			const loading = '<div style="text-align:center;">' + letsgo.loading_html + '</div>';

			// Remove all the messages
			$('#erpwoosync_box_message').removeClass('error').removeClass('success').removeClass('warning');
			
			// Put loading icon in message section
			$('#erpwoosync_box_message').html(loading);
			
			// Empty button content
			$('#erpwoosync_box_button').empty();


			// We prepare the information to Ajax event
			const data = {
				action: slug + '_set_unassign',
				wpnonce: letsgo.wpnonce
			};

			const onSuccess = function (response) {
				
				$('#erpwoosync_box_message').addClass(response.data.class);
				$('#erpwoosync_box_message').html(response.data.message);

				if( response.success ) {
					setTimeout(window.location.reload.bind(window.location), 300);
				}
			};

			const onError = function(jqxhr, textStatus, error) {
				console.log('License Ajax unassign error: ' + textStatus + ' - ' + error);
			};


			if( letsgo && letsgo.ajax_url ) {
				ERPWooSyncLicense.sendAjax(data, onSuccess, onError);
			}
		},
		
		/**
		 * Ajax event
		 * @param  json data
		 * @param  function success_bt
		 * @param  function error_bt
		 * @return mixed
		 */
		sendAjax: function(data, success_bt, error_bt) {

			let ajax = {
					url: letsgo.ajax_url,
					data: data,
					cache: false,
					type: 'POST',
					dataType: 'json',
					timeout: 	30000
				},
				success = success_bt || false,
				error = error_bt || false;
			
			// Set success callback if supplied.
			if (success) {
				ajax.success = success;
			}

			// Set error callback if supplied.
			if (error) {
				ajax.error = error;
			}

			$.ajax(ajax);
		}
	};

	ERPWooSyncLicense.init();
	// Add to global scope.
	window.erpwoosync_license = ERPWooSyncLicense;
})(jQuery);
