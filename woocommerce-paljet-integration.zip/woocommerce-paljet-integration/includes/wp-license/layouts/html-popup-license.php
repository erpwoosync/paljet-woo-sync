<div id="erpwoosync_box_license" style="display: none;">
	<a href="" id="erpwoosync_box_close"> <?php echo esc_html__( 'Close Popup', 'erpwoosync' ); ?></a>
	<h2><?php echo esc_html__( 'License Status', 'erpwoosync' ); ?></h2>

	<div id="erpwoosync_box_content">
		<div id="erpwoosync_box_message"></div>
		<hr />
		<div id="erpwoosync_box_button"></div>
	</div>
	<div id="erpwoosync_box_link">
		<a href="https://www.erpwoosync.com/#" target="_blank">
			<?php echo esc_html__( 'Where do I find my License Code?', 'erpwoosync' ); ?>
		</a>
		<br />
		<a href="https://www.erpwoosync.com/#" target="_blank">
			<?php echo esc_html__( 'Manager License from your site', 'erpwoosync' ); ?>
		</a>
	</div>
</div>