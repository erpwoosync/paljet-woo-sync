<a
	class="button wc-action-button wc-action-button-<?php echo $action; ?> <?php echo $action; ?> tips"
	href=""
	aria-label="<?php echo $title; ?>"
	data-tip="<?php echo $title; ?>"
	data-product="<?php echo $product; ?>"
><?php echo $title; ?>
</a>