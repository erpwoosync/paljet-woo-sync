<button
	class="button <?php echo $action; ?>"
	data-product="<?php echo $product; ?>"
><?php echo $title; ?>
</button>